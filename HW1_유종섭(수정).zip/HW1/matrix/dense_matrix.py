def add(dm1, dm2):
    result_add = [len(dm2[0]) * [0] for i in range(len(dm1))]
    for i in range(len(result_add)):
        for j in range(len(dm1[i])):
            result_add[i][j] += dm1[i][j] + dm2[i][j]
    return result_add


def multiply(dm1, dm2):
    multiply = [len(dm2[0]) * [0] for i in range(len(dm1))]
    for i in range(len(multiply)):
        for j in range(len(dm1[i])):
            for k in range(len(dm1[i])):
                multiply[i][j] += dm1[i][k] * dm2[k][j]
    return multiply


def add_handle_exception(dm1,dm2):
    for i in range(len(dm1) - 1):
        if len(dm1[i]) != len(dm1[i + 1]):
            raise Exception('matrix columns are not consistent')
    if len(dm1) != len(dm2):
        raise Exception("different matrix size")

    for i in range(len(dm2)):
        for j in range(len(dm1[i])):
            if len(dm2[i]) != len(dm2[j]):
                raise Exception('matrix columns are not consistent')



def multiply_handle_exception(dm1,dm2):
    for i in range(len(dm1)):
        for j in range(len(dm1[i])):
            if len(dm1[i]) != len(dm1[j]):
                raise Exception('matrix columns are not consistent')
            if len(dm1[i]) != len(dm2):
                raise Exception('cannot multiply (2,2) x (1,2)')


