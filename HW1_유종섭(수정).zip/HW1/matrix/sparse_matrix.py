def add(sm1, sm2):
    result_dict = {}
    if (sm1['rows'] == sm2['rows']) and (sm1['cols'] == sm2['cols']):
        print("They are addable.")
        for i in range(sm1['rows']):
            for j in range(sm1['cols']):
                if f'{i}{j}' in sm1:
                    pass
                else:
                    sm1.update({f'{i}{j}':0})
        for i in range(sm2['rows']):
            for j in range(sm2['cols']):
                if f'{i}{j}' in sm2:
                    pass
                else:
                    sm2.update({f'{i}{j}':0})
        for sm1_idx in sm1:
            for sm2_idx in sm2:
                result_dict.update({'rows' : sm1['rows'], 'cols' : sm1['cols']})
                if sm1_idx == sm2_idx:
                    add_dict = {f'{sm1_idx}':sm1[sm1_idx]+ sm2[sm2_idx]}
                    result_dict.update(add_dict)
                else:
                    pass
        result_dict_final = {key:value for key, value in result_dict.items() if value != 0}
        return result_dict_final


def dense(res):
    sm_to_dm = []
    result_list = []

    for i in range(res['rows']):
        for j in range(res['cols']):
            if f'{i}{j}' in res:
                pass
            else:
                res.update({f'{i}{j}': 0})

    for i in range(res['rows']):
        for j in range(res['rows']):
            sm_to_dm.append(res[f'{i}{j}'])

    for i in range(res['rows']):
        result_list.append(list(sm_to_dm[i*3:(i+1)*3]))

    return result_list

def add_handle_exception(sm1, sm2):
    if 'rows' not in sm1.keys() or 'cols' not in sm1.keys():
        raise Exception("either 'rows' or 'cols' is not in keys")
    if 'rows' not in sm2.keys() or 'cols' not in sm2.keys():
        raise Exception("either 'rows' or 'cols' is not in keys")
    new_sm1 = sm1.copy()
    new_sm2 = sm2.copy()
    for i in range(sm1['rows']):
        for j in range(sm1['cols']):
            if f'{i}{j}' in sm1:
                pass
            else:
                new_sm1.update({f'{i}{j}': 0})
    for i in range(sm2['rows']):
        for j in range(sm2['cols']):
            if f'{i}{j}' in sm2:
                pass
            else:
                new_sm2.update({f'{i}{j}': 0})
    index_len_sm1 = sm1['rows']*sm1['cols']
    index_len_sm2 = sm2['rows']*sm2['cols']
    if (len(new_sm1.keys()) > index_len_sm1+2) or (len(new_sm2.keys()) > index_len_sm2+2) :
        raise Exception("index out of bound")
    if (sm1['rows'] != sm2['rows']) or (sm1['cols'] != sm2['cols']):
        raise Exception("different matrix size")





def dense_handle_exception(sm1):
    if 'rows' not in sm1.keys() or 'cols' not in sm1.keys():
        raise Exception("either 'rows' or 'cols' is not in keys")
    for i in range(3):
        for j in range(3):
            if f'{i}{j}' in sm1 and (sm1['rows'] < i + 1 or sm1['cols'] < j + 2):
                raise Exception("index out of bound")
